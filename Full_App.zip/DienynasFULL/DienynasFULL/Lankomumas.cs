﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.IO;



namespace DienynasFULL
{
    public partial class Lankomumas : UserControl
    {
        static ComboBox Grupes = new ComboBox();
        static Panel panels1 = new Panel();
        static Panel panels2 = new Panel();
        static Panel panels3 = new Panel();
        static TableLayoutPanel tbls = new TableLayoutPanel();
        public int Buvo;
        public int Nebuvo;
        public int SPusryciai;
        public int SPietus;
        public int SVakariene;
        

        public Lankomumas()
        {
            InitializeComponent();
            Grupes = comboBox2;
            Grupes.DropDownStyle = ComboBoxStyle.DropDownList;
            Grupes.SelectedIndex = 0;
            panels1 = panel2;
            panels2 = panel3;
            panels3 = panel4;
            tbls = tableLayoutPanel1;
            
        }

        private void Lankomumas_Load(object sender, EventArgs e)
        {
            TableGeneravimas();
            panel2.Visible = true;
            panel3.Visible = false;
            panel4.Visible = false;
        }

        private void comboBox2_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (Grupes.SelectedIndex == 0)
            {
                panel2.Visible = true;
                panel3.Visible = false;
                panel4.Visible = false;
                TableGeneravimas();
            }
            if (Grupes.SelectedIndex == 1)
            {
                panel2.Visible = false;
                panel3.Visible = true;
                panel4.Visible = false;
                TableGeneravimas();
            }
            if (Grupes.SelectedIndex == 2)
            {
                panel2.Visible = false;
                panel3.Visible = false;
                panel4.Visible = true;
                TableGeneravimas();
            }
        }

        public  void TableGeneravimas()
        {
            if (Grupes.SelectedIndex == 0)
            {
                panels1.Controls.Clear();
                SqlConnection PoSauleConnection = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\herku\Desktop\Kurybinis\DarzelioDienynas\DienynasFULL\DienynasFULL\dbPoSaule.mdf;Integrated Security=True;Connect Timeout=30");
                PoSauleConnection.Open();

                SqlDataAdapter SDA = new SqlDataAdapter("SELECT * FROM tbl_pieva", PoSauleConnection);
                SDA.SelectCommand.ExecuteNonQuery();
                DataTable dt = new DataTable();
                SDA.Fill(dt);
                int start = 0;

                for (int i = 0; i < dt.Rows.Count; i++)
                {
                    string IDtext = dt.Rows[i]["Id"].ToString();
                    int IDS = Int32.Parse(IDtext);
                    string name = dt.Rows[i]["Vardas"].ToString();
                    string surname = dt.Rows[i]["Pavardė"].ToString();
                    TableLayoutPanel panel = Vaikas(name, surname, start);
                    panels1.Controls.Add(panel);
                    start += 37;
                    SPusryciai = dt.Rows.Count;
                    SPietus = dt.Rows.Count;
                    SVakariene = dt.Rows.Count;
                    Buvo = dt.Rows.Count;
                    label11.Text = Buvo.ToString() ;
                    label13.Text = SPusryciai.ToString();
                    label14.Text = SPietus.ToString();
                    label15.Text = SVakariene.ToString();
                }

                PoSauleConnection.Close();
            }
            if (Grupes.SelectedIndex == 1)
            {
                panels2.Controls.Clear();
                SqlConnection PoSauleConnection = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\herku\Desktop\Kurybinis\DarzelioDienynas\DienynasFULL\DienynasFULL\dbPoSaule.mdf;Integrated Security=True;Connect Timeout=30");
                PoSauleConnection.Open();

                SqlDataAdapter SDA = new SqlDataAdapter("SELECT * FROM tbl_miskas", PoSauleConnection);
                SDA.SelectCommand.ExecuteNonQuery();
                DataTable dt = new DataTable();
                SDA.Fill(dt);
                int start = 0;

                for (int i = 0; i < dt.Rows.Count; i++)
                {
                    string IDtext = dt.Rows[i]["Id"].ToString();
                    int IDS = Int32.Parse(IDtext);
                    string name = dt.Rows[i]["Vardas"].ToString();
                    string surname = dt.Rows[i]["Pavardė"].ToString();
                    TableLayoutPanel panel = Vaikas(name, surname, start);
                    panels2.Controls.Add(panel);
                    start += 37;
                    SPusryciai = dt.Rows.Count;
                    SPietus = dt.Rows.Count;
                    SVakariene = dt.Rows.Count;
                    Buvo = dt.Rows.Count;
                    label11.Text = Buvo.ToString();
                    label13.Text = SPusryciai.ToString();
                    label14.Text = SPietus.ToString();
                    label15.Text = SVakariene.ToString();
                }

                PoSauleConnection.Close();
            }
            if (Grupes.SelectedIndex == 2)
            {
                panels3.Controls.Clear();
                SqlConnection PoSauleConnection = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\herku\Desktop\Kurybinis\DarzelioDienynas\DienynasFULL\DienynasFULL\dbPoSaule.mdf;Integrated Security=True;Connect Timeout=30");
                PoSauleConnection.Open();

                SqlDataAdapter SDA = new SqlDataAdapter("SELECT * FROM tbl_upe", PoSauleConnection);
                SDA.SelectCommand.ExecuteNonQuery();
                DataTable dt = new DataTable();
                SDA.Fill(dt);
                int start = 0;

                for (int i = 0; i < dt.Rows.Count; i++)
                {
                    string IDtext = dt.Rows[i]["Id"].ToString();
                    int IDS = Int32.Parse(IDtext);
                    string name = dt.Rows[i]["Vardas"].ToString();
                    string surname = dt.Rows[i]["Pavardė"].ToString();
                    TableLayoutPanel panel = Vaikas(name, surname, start);
                    panels3.Controls.Add(panel);
                    start += 37; 
                    Buvo = dt.Rows.Count;
                    SPusryciai = dt.Rows.Count;
                    SPietus = dt.Rows.Count;
                    SVakariene = dt.Rows.Count;
                    label11.Text = Buvo.ToString();
                    label13.Text = SPusryciai.ToString();
                    label14.Text = SPietus.ToString();
                    label15.Text = SVakariene.ToString();
                }

                PoSauleConnection.Close();
            }
        }

        public TableLayoutPanel Vaikas(string name, string surname, int start)
        {
            TableLayoutPanel tbl = new TableLayoutPanel();
            tbl.Name = name;
            tbl.RowCount = 0;
            tbl.Width = 454;
            tbl.Height = 37;
            tbl.Location = new Point(0, start);
            tbl.CellBorderStyle = TableLayoutPanelCellBorderStyle.Single;
            tbl.ColumnCount = 4;
            tbl.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 42f));
            tbl.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 14f));
            tbl.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 16f));
            tbl.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 28f));

            Label vardas = new Label();
            vardas.Name = name;
            vardas.Text = name + " " + surname;
            vardas.Font = new Font("Serif", 12);
            vardas.Width = 300;
            vardas.Dock = DockStyle.None;
            vardas.Anchor = AnchorStyles.Left;
            tbl.Controls.Add(vardas, 0, 0);

            CheckBox buvo = new CheckBox();
            buvo.Name = "b"+name;
            buvo.Text = "";
            buvo.Anchor = AnchorStyles.None;
            buvo.Dock = DockStyle.None;
            buvo.Margin = new Padding(23, 0, 0, 0);
            buvo.Checked = true;
            buvo.CheckedChanged += new EventHandler(this.buvo_Checked);
            tbl.Controls.Add(buvo, 1, 0);

            CheckBox nebuvo = new CheckBox();
            nebuvo.Name ="1"+name;
            nebuvo.Text = "";
            nebuvo.Anchor = AnchorStyles.None;
            nebuvo.Dock = DockStyle.None;
            nebuvo.Margin = new Padding(28, 0, 0, 0);
            nebuvo.Checked = false;
            string names = buvo.Name;
            nebuvo.CheckedChanged += new EventHandler(this.nebuvo_Checked);
            tbl.Controls.Add(nebuvo, 2, 0);

            Panel maistas = new Panel();
            maistas.Name = name;
            maistas.Width = 151;
            maistas.Height = 29;

            CheckBox pusryciai = new CheckBox();
            pusryciai.Name = "2" + name;
            pusryciai.Text = null;
            pusryciai.Anchor = AnchorStyles.None;
            pusryciai.Dock = DockStyle.None;
            pusryciai.Location = new Point(38, 8);
            pusryciai.Height = 14;
            pusryciai.Width = 15;
            pusryciai.Checked = true;
            pusryciai.CheckedChanged += new EventHandler(this.pusryciai_Checked);

            CheckBox pietus = new CheckBox();
            pietus.Name ="3" + name;
            pietus.Text = null;
            pietus.Anchor = AnchorStyles.None;
            pietus.Dock = DockStyle.None;
            pietus.Location = new Point(68, 8);
            pietus.Height = 14;
            pietus.Width = 15;
            pietus.Checked = true;
            pietus.CheckedChanged += new EventHandler(this.pietus_Checked);


            CheckBox vakariene = new CheckBox();
            vakariene.Name ="4" + name;
            vakariene.Text = null;
            vakariene.Anchor = AnchorStyles.None;
            vakariene.Dock = DockStyle.None;
            vakariene.Location = new Point(96, 8);
            vakariene.Height = 14;
            vakariene.Width = 15;
            vakariene.Checked = true;
            vakariene.CheckedChanged += new EventHandler(this.vakariene_Checked);

            maistas.Controls.Add(pusryciai);
            maistas.Controls.Add(pietus);
            maistas.Controls.Add(vakariene);
            tbl.Controls.Add(maistas, 3, 0);
            return tbl;
        }

        private void buvo_Checked(object sender, EventArgs e)
        {
            CheckBox chk = (sender as CheckBox);
            string name = chk.Name.Remove(0, 1);
            CheckBox nebuvo = this.Controls.Find("1"+name, true).First() as CheckBox;
            CheckBox Pusryciai = this.Controls.Find("2" + name, true).First() as CheckBox;
            CheckBox Pietus = this.Controls.Find("3" + name, true).First() as CheckBox;
            CheckBox Vakariene = this.Controls.Find("4" + name, true).First() as CheckBox;
            if (chk.Checked)
            {
                Pusryciai.Checked = true;
                Pietus.Checked = true;
                Vakariene.Checked = true;
                nebuvo.Checked = false;
                Nebuvo -= 1;
                Buvo += 1;
                SPusryciai += 1;
                SPietus += 1;
                SVakariene += 1;
            }
            label11.Text = Buvo.ToString();
            label12.Text = Nebuvo.ToString();
            label13.Text = SPusryciai.ToString();
            label14.Text = SPietus.ToString();
            label15.Text = SVakariene.ToString();
        }

        private void nebuvo_Checked(object sender, EventArgs e)
        {
            CheckBox chk = (sender as CheckBox);
            string name = chk.Name.Remove(0, 1);
            CheckBox buvo = this.Controls.Find("b"+name, true).First() as CheckBox;
            CheckBox Pusryciai = this.Controls.Find("2" + name, true).First() as CheckBox;
            CheckBox Pietus = this.Controls.Find("3" + name, true).First() as CheckBox;
            CheckBox Vakariene = this.Controls.Find("4" + name, true).First() as CheckBox;
            if (chk.Checked)
            {
                buvo.Checked = false;
                Pusryciai.Checked = false;
                Pietus.Checked = false;
                Vakariene.Checked = false;
                
                Nebuvo += 1;
                Buvo -= 1;
              
            }
            label11.Text = Buvo.ToString();
            label12.Text = Nebuvo.ToString();
          
        }

        private void pusryciai_Checked(object sender, EventArgs e)
        {
            CheckBox chk = (sender as CheckBox);
            if(chk.Checked)
            {
                SPusryciai += 1;
                label13.Text = SPusryciai.ToString();
                
            }
            if(!chk.Checked)
            {
                SPusryciai -= 1;
                label13.Text = SPusryciai.ToString();
               
            }
        }
        private void pietus_Checked(object sender, EventArgs e)
        {
            CheckBox chk = (sender as CheckBox);
            if (chk.Checked)
            {
                SPietus += 1;             
                label14.Text = SPietus.ToString();            
            }
            if (!chk.Checked)
            {
                SPietus -= 1;
                label14.Text = SPietus.ToString();
               
            }
        }
        private void vakariene_Checked(object sender, EventArgs e)
        {
            CheckBox chk = (sender as CheckBox);
            if (chk.Checked)
            {
                SVakariene += 1;
                label15.Text = SVakariene.ToString();
            }
            if (!chk.Checked)
            {
                SVakariene -= 1;
                label15.Text = SVakariene.ToString();
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Sėkmingai išsaugota");
        }
    }
    
}
