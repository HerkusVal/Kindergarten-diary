﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DienynasFULL
{
    public partial class Atostogos : UserControl
    {
        public Atostogos()
        {
            InitializeComponent();
            comboBox1.DropDownStyle = ComboBoxStyle.DropDownList;
            comboBox1.SelectedIndex = 0;
        }

        private void Atostogos_Load(object sender, EventArgs e)
        {
            label9.Text = DateTime.Now.ToShortDateString() + " — "; ;
            label10.Text = DateTime.Now.ToShortDateString();
        }

        private void monthCalendar1_DateChanged(object sender, DateRangeEventArgs e)
        {
            label9.Text = monthCalendar1.SelectionRange.Start.ToShortDateString() +" — ";
        }

        private void monthCalendar2_DateChanged(object sender, DateRangeEventArgs e)
        {
            label10.Text = monthCalendar2.SelectionRange.End.ToShortDateString();
        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Sėkmingai išsaugota");
            label7.Text = 7.ToString();
            label4.Text = label9.Text + label10.Text;
        }
    }
}
