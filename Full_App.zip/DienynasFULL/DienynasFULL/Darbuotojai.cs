﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.IO;


namespace DienynasFULL
{
    public partial class Darbuotojai : UserControl
    {
        static Darbuotojai darbuotojai = new Darbuotojai();
        static DarbuotojuRegistracija darbuotojuRegistracija = new DarbuotojuRegistracija();
        public static int ButtonID;

        public Darbuotojai()
        {
            InitializeComponent();
            darbuotojai = this;
        }

        private void Darbuotojai_Load(object sender, EventArgs e)
        {
            MygtukuGeneravimas();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            darbuotojuRegistracija.Show();
            DarbuotojuRegistracija.UpdateOff();
            DarbuotojuRegistracija.NewADD();
        }

        public static void MygtukuGeneravimas()
        {
            SqlConnection PoSauleConnection = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\herku\Desktop\Kurybinis\DarzelioDienynas\DienynasFULL\DienynasFULL\dbPoSaule.mdf;Integrated Security=True;Connect Timeout=30");
            PoSauleConnection.Open();

            SqlDataAdapter SDA = new SqlDataAdapter("SELECT * FROM tbl_dButtons", PoSauleConnection);
            SDA.SelectCommand.ExecuteNonQuery();
            DataTable dt = new DataTable();
            SDA.Fill(dt);

            int start = 15;
            int end = 0;
            for (int i = 0; i < dt.Rows.Count; i++)
            {

                string IDtext = dt.Rows[i]["Id"].ToString();
                int IDS = Int32.Parse(IDtext);
                string name = dt.Rows[i]["Name"].ToString();
                byte[] imag = ((byte[])dt.Rows[i]["Image"]);
                MemoryStream memoryStream = new MemoryStream(imag);
                Image imga = Image.FromStream(memoryStream);
                Label label = Tekstas(name, start, end);
                darbuotojai.panel1.Controls.Add(label);
                Button button = Darbuotojas(IDS, start, end, name, imga);
                darbuotojai.panel1.Controls.Add(button);
                //Layout
                if (start >= 300)
                {
                    end += 215;
                    start = 15;
                }
                else
                {
                    start += 195;
                }
            }

            PoSauleConnection.Close();
        }


        //Darbuotojo mygtuko sukurimas
        static Button Darbuotojas(int i, int start, int end, string name, Image image)
        {
            Button but = new Button();
            but.Name = i.ToString();
            but.ForeColor = Color.White;
            but.BackColor = Color.SlateGray;
            but.Font = new Font("Serif", 24, FontStyle.Bold);
            but.Width = 190;
            but.Height = 175;
            but.Location = new Point(start, end);
            but.TextAlign = ContentAlignment.BottomCenter;
            but.Margin = new Padding(5);
            but.Click += new EventHandler(darbuotojai.button_click);
            but.ImageAlign = ContentAlignment.MiddleCenter;
            but.Image = (Image)(new Bitmap(image, new Size(190, 175)));
            return but;
        }

        static Label Tekstas(string name, int start, int end)
        {
            Label teks = new Label();
            teks.Text = name;
            teks.Font = new Font("Serif", 18, FontStyle.Bold);
            teks.Height = 30;
            teks.Width = 190;
            teks.TextAlign = ContentAlignment.MiddleCenter;
            teks.Location = new Point(start, end + 175);
            return teks;
        }

        //Paspaudimas ant darbuotojo
        void button_click(object sender, EventArgs e)
        {
            DarbuotojuRegistracija.UpdateOn();
            Button btn = sender as Button;
            darbuotojuRegistracija.Show();
            int a = Int32.Parse(btn.Name);
            DarbuotojuRegistracija.FillRegister(a);
            DarbuotojuRegistracija.FillImage(a);
            DarbuotojuRegistracija.SetID(a);
        }

        //Mygtuko istrinimas
        public static void DeleteButton()
        {
            darbuotojai.panel1.Controls.Clear();
            MessageBox.Show("Sėkmingai ištrinta");
            darbuotojuRegistracija.Hide();
        }

        public static void UpdateButton()
        {
            darbuotojai.panel1.Controls.Clear();
            MessageBox.Show("Sėkmingai atnaujinta");
            darbuotojuRegistracija.Hide();
        }
    }
}

