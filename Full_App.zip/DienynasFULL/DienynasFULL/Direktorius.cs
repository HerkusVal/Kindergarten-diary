﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DienynasFULL
{
    public partial class Direktorius : Form
    {
        public Direktorius()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            darbuotojai1.Visible = false;
            atostogos1.Visible = false;
            mokesciai1.Visible = false;
            lankomumas1.Visible = true;
            settings1.Visible = false;
            vaikai1.Visible = false;
            panel4.Height = button1.Height;
            panel4.Top = button1.Top;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            darbuotojai1.Visible = false;
            atostogos1.Visible = false;
            mokesciai1.Visible = false;
            lankomumas1.Visible = false;
            settings1.Visible = false;
            vaikai1.Visible = true;
            panel4.Height = button2.Height;
            panel4.Top = button2.Top;
        }

        private void button4_Click(object sender, EventArgs e)
        {
            darbuotojai1.Visible = true;
            atostogos1.Visible = false;
            mokesciai1.Visible = false;
            lankomumas1.Visible = false;
            settings1.Visible = false;
            vaikai1.Visible = false;
            panel4.Height = button4.Height;
            panel4.Top = button4.Top;

        }

        private void button3_Click(object sender, EventArgs e)
        {
            darbuotojai1.Visible = false;
            atostogos1.Visible = true;
            mokesciai1.Visible = false;
            lankomumas1.Visible = false;
            settings1.Visible = false;
            vaikai1.Visible = false;
            panel4.Height = button3.Height;
            panel4.Top = button3.Top;
        }

        private void button5_Click(object sender, EventArgs e)
        {
            darbuotojai1.Visible = false;
            atostogos1.Visible = false;
            mokesciai1.Visible = true;
            lankomumas1.Visible = false;
            settings1.Visible = false;
            vaikai1.Visible = false;
            panel4.Height = button5.Height;
            panel4.Top = button5.Top;
        }

       

        private void button7_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void Direktorius_Load(object sender, EventArgs e)
        {
            darbuotojai1.Visible = false;
            atostogos1.Visible = false;
            mokesciai1.Visible = false;
            lankomumas1.Visible = true;
            settings1.Visible = false;
            vaikai1.Visible = false;
            panel4.Height = button1.Height;
            panel4.Top = button1.Top;
        }

        private void button8_Click(object sender, EventArgs e)
        {
            this.Visible = false;
            var LoginScreen = new LoginScreen();
            LoginScreen.Show();
        }

        private void vaikai1_Load(object sender, EventArgs e)
        {

        }
    }
}
