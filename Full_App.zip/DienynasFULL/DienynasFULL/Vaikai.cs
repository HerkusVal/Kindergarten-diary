﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.IO;

namespace DienynasFULL
{
    public partial class Vaikai : UserControl
    {
        static Vaikai vaikai = new Vaikai();
        static VaikuRegistracija vaikuRegistracija = new VaikuRegistracija();
        public static ComboBox comboBox = new ComboBox();
        public static int ButtonID;

        public Vaikai()
        {
            InitializeComponent();
            vaikai = this;
            comboBox = comboBox1;
            comboBox.DropDownStyle = ComboBoxStyle.DropDownList;
            comboBox.SelectedIndex = 0;
        }

        private void Vaikai_Load(object sender, EventArgs e)
        {
            MygtukuGeneravimas();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            vaikuRegistracija.Show();
            VaikuRegistracija.UpdateOff();
            VaikuRegistracija.NewADD();
        }

        public static void MygtukuGeneravimas()
        {
            SqlConnection PoSauleConnection = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\herku\Desktop\Kurybinis\DarzelioDienynas\DienynasFULL\DienynasFULL\dbPoSaule.mdf;Integrated Security=True;Connect Timeout=30");
            PoSauleConnection.Open();

            SqlDataAdapter SDA = new SqlDataAdapter();
            DataTable dt = new DataTable();

            if (comboBox.SelectedIndex == 0)
            {
                SDA = new SqlDataAdapter("SELECT * FROM tbl_pButtons", PoSauleConnection);
                SDA.SelectCommand.ExecuteNonQuery();
                SDA.Fill(dt);
                int start = 15;
                int end = 0;
                for (int i = 0; i < dt.Rows.Count; i++)
                {

                    string IDtext = dt.Rows[i]["Id"].ToString();
                    int IDS = Int32.Parse(IDtext);
                    string name = dt.Rows[i]["Name"].ToString();
                    byte[] imag = ((byte[])dt.Rows[i]["Image"]);
                    MemoryStream memoryStream = new MemoryStream(imag);
                    Image imga = Image.FromStream(memoryStream);
                    Label label = Tekstas(name, start, end);
                    vaikai.panel1.Controls.Add(label);
                    Button button = Vaikas(IDS, start, end, name, imga);
                    vaikai.panel1.Controls.Add(button);
                    //Layout
                    if (start >= 300)
                    {
                        end += 215;
                        start = 15;
                    }
                    else
                    {
                        start += 195;
                    }
                }
            }
            if (comboBox.SelectedIndex == 1)
            {
                SDA = new SqlDataAdapter("SELECT * FROM tbl_mButtons", PoSauleConnection);
                SDA.SelectCommand.ExecuteNonQuery();
                SDA.Fill(dt);
                int start = 15;
                int end = 0;
                for (int i = 0; i < dt.Rows.Count; i++)
                {

                    string IDtext = dt.Rows[i]["Id"].ToString();
                    int IDS = Int32.Parse(IDtext);
                    string name = dt.Rows[i]["Name"].ToString();
                    byte[] imag = ((byte[])dt.Rows[i]["Image"]);
                    MemoryStream memoryStream = new MemoryStream(imag);
                    Image imga = Image.FromStream(memoryStream);
                    Label label = Tekstas(name, start, end);
                    vaikai.panel2.Controls.Add(label);
                    Button button = Vaikas(IDS, start, end, name, imga);
                    vaikai.panel2.Controls.Add(button);
                    //Layout
                    if (start >= 300)
                    {
                        end += 205;
                        start = 15;
                    }
                    else
                    {
                        start += 195;
                    }
                }
            }
            if (comboBox.SelectedIndex == 2)
            {
                SDA = new SqlDataAdapter("SELECT * FROM tbl_uButtons", PoSauleConnection);
                SDA.SelectCommand.ExecuteNonQuery();
                SDA.Fill(dt);
                int start = 15;
                int end = 0;
                for (int i = 0; i < dt.Rows.Count; i++)
                {

                    string IDtext = dt.Rows[i]["Id"].ToString();
                    int IDS = Int32.Parse(IDtext);
                    string name = dt.Rows[i]["Name"].ToString();
                    byte[] imag = ((byte[])dt.Rows[i]["Image"]);
                    MemoryStream memoryStream = new MemoryStream(imag);
                    Image imga = Image.FromStream(memoryStream);
                    Label label = Tekstas(name, start, end);
                    vaikai.panel3.Controls.Add(label);
                    Button button = Vaikas(IDS, start, end, name, imga);
                    vaikai.panel3.Controls.Add(button);
                    //Layout
                    if (start >=300)
                    {
                        end += 205;
                        start = 15;
                    }
                    else
                    {
                        start += 195;
                    }
                }
            }
            PoSauleConnection.Close();
        }
        

        //Darbuotojo mygtuko sukurimas
        static Button Vaikas(int i, int start, int end, string name, Image image)
        {
            Button but = new Button();
            but.Name = i.ToString();
            but.Text = "";
            but.ForeColor = Color.White;
            but.BackColor = Color.White;
            but.Width = 190;
            but.Height = 175;
            but.Location = new Point(start, end);
            but.TextAlign = ContentAlignment.BottomCenter;
            but.Margin = new Padding(5);
            but.Click += new EventHandler(vaikai.button_click);
            but.ImageAlign = ContentAlignment.MiddleCenter;
            but.Image = (Image)(new Bitmap(image, new Size(190, 175)));
            return but;
        }

        static Label Tekstas(string name, int start, int end)
        {
            Label teks = new Label();
            teks.Text = name;
            teks.Font = new Font("Serif", 18, FontStyle.Bold);
            teks.Height = 30;
            teks.Width = 190;
            teks.TextAlign = ContentAlignment.MiddleCenter;
            teks.Location = new Point(start, end+175);
            return teks;
        }

        //Paspaudimas ant darbuotojo
        void button_click(object sender, EventArgs e)
        {
            VaikuRegistracija.UpdateOn();
            Button btn = sender as Button;
            vaikuRegistracija.Show();
            int a = Int32.Parse(btn.Name);
            VaikuRegistracija.FillRegister(a);
            VaikuRegistracija.FillImage(a);
            VaikuRegistracija.SetID(a);
        }

        //Mygtuko istrinimas
        public static void DeleteButton()
        {
            vaikai.panel1.Controls.Clear();
            vaikai.panel2.Controls.Clear();
            vaikai.panel3.Controls.Clear();
            MessageBox.Show("Sėkmingai ištrinta");
            vaikuRegistracija.Hide();
        }

        public static void UpdateButton()
        {
            vaikai.panel1.Controls.Clear();
            vaikai.panel2.Controls.Clear();
            vaikai.panel3.Controls.Clear();
            MessageBox.Show("Sėkmingai atnaujinta");
            vaikuRegistracija.Hide();
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (comboBox1.SelectedIndex == 0)
            {
                panel1.Visible = true;
                panel2.Visible = false;
                panel3.Visible = false;
                MygtukuGeneravimas();
            }
            if (comboBox1.SelectedIndex == 1)
            {
                panel1.Visible = false;
                panel2.Visible = true;
                panel3.Visible = false;
                MygtukuGeneravimas();
            }
            if (comboBox1.SelectedIndex == 2)
            {
                panel1.Visible = false;
                panel2.Visible = false;
                panel3.Visible = true;
                MygtukuGeneravimas();
            }
        }

        
    }
}
