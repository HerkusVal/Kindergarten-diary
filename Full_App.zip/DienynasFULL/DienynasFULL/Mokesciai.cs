﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.IO;

namespace DienynasFULL
{
    public partial class Mokesciai : UserControl
    {
        public Mokesciai()
        {
            InitializeComponent();
            comboBox1.DropDownStyle = ComboBoxStyle.DropDownList;
            comboBox1.SelectedIndex = 5;
            comboBox2.DropDownStyle = ComboBoxStyle.DropDownList;
            comboBox2.SelectedIndex = 0;
        }

        private void Mokesciai_Load(object sender, EventArgs e)
        {
            TableGeneravimas();
            panel2.Visible = true;
            panel3.Visible = false;
            panel4.Visible = false;
        }

      

        public void TableGeneravimas()
        {
            if (comboBox2.SelectedIndex == 0)
            {
                panel2.Controls.Clear();
                SqlConnection PoSauleConnection = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\herku\Desktop\Kurybinis\DarzelioDienynas\DienynasFULL\DienynasFULL\dbPoSaule.mdf;Integrated Security=True;Connect Timeout=30");
                PoSauleConnection.Open();

                SqlDataAdapter SDA = new SqlDataAdapter("SELECT * FROM tbl_pieva", PoSauleConnection);
                SDA.SelectCommand.ExecuteNonQuery();
                DataTable dt = new DataTable();
                SDA.Fill(dt);
                int start = 0;

                for (int i = 0; i < dt.Rows.Count; i++)
                {
                    string IDtext = dt.Rows[i]["Id"].ToString();
                    int IDS = Int32.Parse(IDtext);
                    string name = dt.Rows[i]["Vardas"].ToString();
                    string surname = dt.Rows[i]["Pavardė"].ToString();
                    TableLayoutPanel panel = Vaikas(name, surname, start);
                    panel2.Controls.Add(panel);
                    start += 37;
                   
                }

                PoSauleConnection.Close();
            }
            if (comboBox2.SelectedIndex == 1)
            {
                panel3.Controls.Clear();
                SqlConnection PoSauleConnection = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\herku\Desktop\Kurybinis\DarzelioDienynas\DienynasFULL\DienynasFULL\dbPoSaule.mdf;Integrated Security=True;Connect Timeout=30");
                PoSauleConnection.Open();

                SqlDataAdapter SDA = new SqlDataAdapter("SELECT * FROM tbl_miskas", PoSauleConnection);
                SDA.SelectCommand.ExecuteNonQuery();
                DataTable dt = new DataTable();
                SDA.Fill(dt);
                int start = 0;

                for (int i = 0; i < dt.Rows.Count; i++)
                {
                    string IDtext = dt.Rows[i]["Id"].ToString();
                    int IDS = Int32.Parse(IDtext);
                    string name = dt.Rows[i]["Vardas"].ToString();
                    string surname = dt.Rows[i]["Pavardė"].ToString();
                    TableLayoutPanel panel = Vaikas(name, surname, start);
                    panel3.Controls.Add(panel);
                    start += 37;
                 
                }

                PoSauleConnection.Close();
            }
            if (comboBox2.SelectedIndex == 2)
            {
                panel4.Controls.Clear();
                SqlConnection PoSauleConnection = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\herku\Desktop\Kurybinis\DarzelioDienynas\DienynasFULL\DienynasFULL\dbPoSaule.mdf;Integrated Security=True;Connect Timeout=30");
                PoSauleConnection.Open();

                SqlDataAdapter SDA = new SqlDataAdapter("SELECT * FROM tbl_upe", PoSauleConnection);
                SDA.SelectCommand.ExecuteNonQuery();
                DataTable dt = new DataTable();
                SDA.Fill(dt);
                int start = 0;

                for (int i = 0; i < dt.Rows.Count; i++)
                {
                    string IDtext = dt.Rows[i]["Id"].ToString();
                    int IDS = Int32.Parse(IDtext);
                    string name = dt.Rows[i]["Vardas"].ToString();
                    string surname = dt.Rows[i]["Pavardė"].ToString();
                    TableLayoutPanel panel = Vaikas(name, surname, start);
                    panel4.Controls.Add(panel);
                    start += 37;         
                }

                PoSauleConnection.Close();
            }
        }

        public TableLayoutPanel Vaikas(string name, string surname, int start)
        {
            TableLayoutPanel tbl = new TableLayoutPanel();
            tbl.Name = name;
            tbl.RowCount = 0;
            tbl.Width = 456;
            tbl.Height = 37;
            tbl.Location = new Point(0, start);
            tbl.CellBorderStyle = TableLayoutPanelCellBorderStyle.Single;
            tbl.ColumnCount = 4;
            tbl.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 64.90f));
            tbl.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 35.10f));


            Label vardas = new Label();
            vardas.Name = name;
            vardas.Text = name + " " + surname;
            vardas.Font = new Font("Serif", 12);
            vardas.Width = 300;
            vardas.Dock = DockStyle.None;
            vardas.Anchor = AnchorStyles.Left;
            tbl.Controls.Add(vardas, 0, 0);

            Button btn = new Button();
            btn.Name = name;
            btn.Text = "Apskaičiuoti";
            btn.Font = new Font("Serif", 12);
            btn.Width = 135;
            btn.Height = 32;
            btn.FlatStyle = FlatStyle.Flat;
            btn.BackColor = Color.Lime;
            btn.Dock = DockStyle.None;
            btn.Anchor = AnchorStyles.None;
            btn.Margin = new Padding(3, 0, 0, 0);
            tbl.Controls.Add(btn, 1, 0);
            btn.Click += new EventHandler(this.button_click);
            return tbl;
        }

        void button_click(object sender, EventArgs e)
        {
            MessageBox.Show("Nėra pakankamai duomenų.");
        }

            private void comboBox2_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (comboBox2.SelectedIndex == 0)
            {
                panel2.Visible = true;
                panel3.Visible = false;
                panel4.Visible = false;
                TableGeneravimas();
            }
            if (comboBox2.SelectedIndex == 1)
            {
                panel2.Visible = false;
                panel3.Visible = true;
                panel4.Visible = false;
                TableGeneravimas();
            }
            if (comboBox2.SelectedIndex == 2)
            {
                panel2.Visible = false;
                panel3.Visible = false;
                panel4.Visible = true;
                TableGeneravimas();
            }
        }
    }
}
