﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace DienynasFULL
{
    public partial class LoginScreen : Form
    {
        Direktorius mainwindow = new Direktorius();

        public LoginScreen()
        {
            InitializeComponent();
        }

        protected override void OnLoad(EventArgs e)
        {
            base.OnLoad(e);

            textBox1.SelectionStart = textBox1.Text.Length;
            textBox1.DeselectAll();

            textBox2.SelectionStart = textBox2.Text.Length;
            textBox2.DeselectAll();
        }

        public void Prisijungimas()
        {
            SqlConnection sqlConnection = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\herku\Desktop\Kurybinis\DarzelioDienynas\DienynasFULL\DienynasFULL\DataLogin.mdf; Integrated Security=True;Connect Timeout=30");
            string quary = "Select * From tbl_login where Username= '" + textBox1.Text.Trim() + "' and Password= '" + textBox2.Text.Trim() + "'";
            SqlDataAdapter sqlData = new SqlDataAdapter(quary, sqlConnection);
            DataTable dataTable = new DataTable();
            sqlData.Fill(dataTable);

            if (dataTable.Rows.Count == 1)
            {
                this.Hide();
                mainwindow.Show();

            }
            else
            {
                MessageBox.Show("Neteisingi prisijungimo duomenys");
            }

        }
     
        private void button1_Click(object sender, EventArgs e)
        {
            Prisijungimas();

            if (checkBox1.Checked == true)
            {
                Properties.Settings.Default.UserName = textBox1.Text;
                Properties.Settings.Default.Password = textBox2.Text;
                Properties.Settings.Default.Remember = true;
                Properties.Settings.Default.Save();
            }
            else
            {
                Properties.Settings.Default.UserName = "";
                Properties.Settings.Default.Password = "";
                Properties.Settings.Default.Remember = false;
                Properties.Settings.Default.Save();
            }
        }

        private void LoginScreen_Load(object sender, EventArgs e)
        {
            if (Properties.Settings.Default.UserName != string.Empty)
            {
                textBox1.Text = Properties.Settings.Default.UserName;
                textBox2.Text = Properties.Settings.Default.Password;
            }

            if (Properties.Settings.Default.Remember == true)
            {
                checkBox1.Checked = true;
            }
            else
            {
                checkBox1.Checked = false;
            }
        }

        private void textBox1_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                Prisijungimas();
            }
        }

        private void textBox2_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                Prisijungimas();
            }
        }
    }
}
